﻿Public Class frmBurger
    Dim btnPrimeClick As Boolean
    Dim btnVeggieClick As Boolean


    Private Sub ButtonPrime_Click(sender As Object, e As EventArgs) Handles btnPrime.Click
        picPrime.Image = Image.FromFile("C:\Users\lee_logan\source\repos\Weekly2Burger\WindowsApp1\Resources\prime.jpg")
        picVeggie.Image = Nothing
        btnPrimeClick = True
        btnVeggieClick = False
        btnSelectMeal.Enabled = True
    End Sub
    Private Sub ButtonVeggie_Click(sender As Object, e As EventArgs) Handles btnVeggie.Click
        picVeggie.Image = Image.FromFile("C:\Users\lee_logan\source\repos\Weekly2Burger\WindowsApp1\Resources\veggie.jpg")
        picPrime.Image = Nothing
        btnPrimeClick = False
        btnVeggieClick = True
        btnSelectMeal.Enabled = True
    End Sub
    Private Sub ButtonSelectMeal_Click(sender As Object, e As EventArgs) Handles btnSelectMeal.Click
        If btnPrimeClick Then
            btnVeggie.Enabled = False
        End If
        If btnVeggieClick Then
            btnPrime.Enabled = False
        End If
        lblInstructions.Visible = False
        btnExit.Enabled = True
        lblConfirmation.Visible = True
    End Sub
    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Private Sub FrmBurger_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LblInstructions_Click(sender As Object, e As EventArgs) Handles lblInstructions.Click

    End Sub
End Class
